/*
The MIT License (MIT)

Copyright (c) 2014 Nicholas Bollweg <nick.bollweg@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/
;(function(d3){
  "use strict";
  d3.fishbone = function(){
    /*
      A Fishbone diagram implemented in d3.
    */

    // private variables
    var _margin = 50,

      // the data...
      _nodes,
      _links;

    // d3 selections and related things used in tick function
    var _node,
      source_x=null,
      target_x=null,
      _nodeID=0,
      _textID=0,
      _link,
      _root,
      _arrowId = function(d){
        var str='';
        if(typeof d!='undefined' && 'depth' in d && d.depth===0){
          str="fishHead";
        }else{
          str="arrow";
        }
        return str;
      },
      _arrowIdEnd=function(d){
        var str='';
        if(typeof d!='undefined' && 'depth' in d && d.depth===0){
          str="fishTail";
        }else{
          str="";
        }
        return str;
      },
      // the children accessor
      _children = function(d){ return d.children; },

      // the label accessor
      _label = function(d){
        if (d.depth == 2) {
          var t = String(d.name).split(":")[0];
          var i = 0;
          var j = 0;
          var k = 0;
          var line = parseInt(t.length / 5) + 1;
          var result = '';
          while (i < t.length) {
            if (d.depth == 2 && d.childIdx % 2 != 0) {
              result += '<tspan x="' + k + '" dy="' + j + '">' + t.substring(i, i + 6) + '</tspan>';
            } else {
              result += '<tspan x="0" dy="' + j + '">' + t.substring(i, i + 6) + '</tspan>';
            }
            k = -18;
            j = 14;
            i += 6;
          }
          return String(d.name)!='undefined'?result:'';
        } else {
          return String(d.name)!='undefined'?String(d.name).split(":")[0]:'';
        }
      },

      // a custom tick accessor
      _perNodeTick = function(d){},


      // arbitrary "nice" values
      _linkScale = d3.scale.log()
        .domain([1, 5])
        .range([4, 10]),

      // the main workhorse of the layout engine
      _force = d3.layout.force()
        .gravity(0)
        .size([
          window.document.documentElement.clientWidth,
          window.document.documentElement.clientHeight
        ])
        .linkDistance(_linkDistance)
        .chargeDistance([0])
        .on("tick", _tick);

    var fb1 = function($){
      /*
        the d3.fishbone modifier, expecting to be called against an `svg:svg`
        or `svg:g` bound to the root node of a navigable tree, i.e.

          d3.select("body").append("svg")
            .datum({name: "foo", children: [{name: "bar"}]})
            .call(d3.fishbone());

        in addition to the properties created by `d3.layout.force`, this will
        add some or all of the following properties, none of which are
        guaranteed to be stable, useful, or sane:

        - depth       int
        - horizontal  bool
        - vertical    bool
        - root        bool
        - childIdx    int
        - maxChildIdx bool
        - totalLinks  [int]
        - linkCount   int
      */

      _links = [];
      _nodes = [];

      // populate the nodes and the links globals as a side effect
      _build_nodes($.datum());
      // set the nodes and the links of the force
      _force
        .nodes(_nodes)
        .links(_links);

      // create the links
      _link = $.selectAll(".link")
        .data(_links);

      _link.enter().append("line");

      _link
        .attr({
          "class": function(d){
            return "link link-"+d.depth+" line-"+(++_nodeID)+(d.source&&d.source.id?(" " + d.source.id):"");
          },
          "nodeid": function(d) {
          return d.source&&d.source.id ? d.source.id : null;
          },
          "marker-end": function(d){
            return d.arrow ? "url(#" + _arrowId(d) + ")" : null;
          },
          "marker-start": function(d){
            return d.arrow ? "url(#" + _arrowIdEnd(d) + ")" : null;
          }
        });

      _link.exit().remove();

      // establish the node selection
      _node = $.selectAll(".node").data(_nodes);


      // actually create nodes
      _node.enter().append("g")
        .attr({
          "class": function(d){
            return "text-"+(++_textID)+" node" + (d.root ? " root" : "") + (d.id != null ? ' ' + d.id : '');
          },
          "nodeid": function(d) {
            return d.id ? d.id : null;
           }
        })

        .append("text");

      _node.select("text")
        .attr({
          "class": function(d){ return "label-move label-" + d.depth; },
          "text-anchor": function(d){
            return !d.depth ? "start" : (d.horizontal) ? "end" : "middle";
          },
          dy: function(d){
            var lct = 6 + ((String(d.name).split(":")[0].length - 1) * 9);
            return !d.depth ? '-' + (lct <= 0 ? 1 : lct) + 'px' : d.horizontal ? ".35em" : d.region === 1 ? "1em" : "-.2em";
          },
          dx: function(d) {
          if (!d.depth) return "3em";
          },
          "style": function(d) {
            return !d.depth ? "writing-mode:tb;" : "";
          }
        })
        .html(_label);

      _node.exit().remove();

      // set up node events
      _node
        .call(_force.drag)
        .on("mousedown", function(d){
          //获取坐标
          //重新渲染鱼骨图
          _force
          .gravity(0)
          .size([
            window.document.documentElement.clientWidth,
            window.document.documentElement.clientHeight
          ])
          .linkDistance(_linkDistance)
          .chargeDistance([0])
          .stop()
          .on("tick", _defined)
          .linkStrength(0)
          .start();
        })
      // select this so we know its width in tick
      _root = $.select(".root").node();
    }; // fb1


    function _arrow($){
      // creates an svg:defs and marker with an arrow if needed...
      // really just an example, as they aren't very flexible
      var defs = $.selectAll("defs").data([1]);

      defs.enter().append("defs");
      // create the arrows
      defs.selectAll("marker#" + _arrowId())
        .data([1])
      .enter().append("marker")
        .attr({
          id: _arrowId(),
          viewBox: "0 -5 10 10",
          refX: 10,
          refY: 0,
          markerWidth: 10,
          markerHeight: 10,
          orient: "auto"
        })
      .append("path")
        .attr({d: "M0,-5L10,0L0,5"});
      defs.selectAll("marker#redarrow")
        .data([1])
      .enter().append("marker")
        .attr({
          id: 'redarrow',
          viewBox: "0 -5 10 10",
          refX: 10,
          refY: 0,
          markerWidth: 10,
          markerHeight: 10,
          orient: "auto",
          style: 'stroke:red;fill:red;'
        })
      .append("path")
        .attr({d: "M0,-5L10,0L0,5"});
      defs.selectAll("marker#greenarrow")
        .data([1])
      .enter().append("marker")
        .attr({
          id: 'greenarrow',
          viewBox: "0 -5 10 10",
          refX: 10,
          refY: 0,
          markerWidth: 10,
          markerHeight: 10,
          orient: "auto",
          style: 'stroke:green;fill:green;'
        })
      .append("path")
        .attr({d: "M0,-5L10,0L0,5"});

        defs.selectAll("marker#fishHead")
        .data([1])
      .enter().append("marker")
        .attr({
          id: 'fishHead',
          refX: 0,
          refY: 25,
          markerWidth: 63,
          markerHeight: 87,
          orient: "auto"
        })
      .append("svg")
        .attr({
        version: "1.1",
        id:"Layer_1",
        xmlns:"http://www.w3.org/2000/svg",
        xlink:"http://www.w3.org/1999/xlink",
        x:"0px",
        y:"0px",
        width:"63px",
        height:"87px",
        viewBox:"0 0 105 145",
        enableBackground:"new 0 0 105 145",
        xml:"preserve"
      })
      .append("image").attr({
        id:"image0",
        width:"63",
        height:"87",
        x:"0",
        y:"0",
        href:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAACRCAYAAADAQ5ZOAAAABGdBTUEAALGPC/xhBQAAACBjSFJN AAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAA B3RJTUUH4wcUARU4Lyrr6QAAFmJJREFUeNrtnXmQI1d9xz+SWpoZjTSjua+dmT3GZ4wdXxifwRBV AkFQVKooIpKiQpIioYoUlVSAQEiFI8QJCUVCCEVCCipgQaiEBCtlwKJ8lm97wfbaa++uZ2fn1n0f LbX65Y9Wa2fHq7nUkmZ3+1OlmtnZ16+f+tuv+73f7/fezyKEIBAMdQN9QH/t50DtdzfgQMMOuDiX CpDb9HsBSNY+KSDp93lLmOwZy733PfAYcEeLz1ME1oFlYBFYqf1+BjgJvO73ecudvhj7Fcu99z0g ACSbDZvVis1mxWa1YrVqPy0Wi1bQYsFqtZxzsBCgqmr931VVRVVVqqpKtapSVasoVRUhxHbtUIB5 4GXg1drP54ATfp9324Mvduoi/fLlR1p2ElUIKhWFSlWhXFGoKNqnXFGQyxXKlQoNlEgDzwPPAk8D j/t93kinL1q7aYtI2yGEoFSuIJfLlMoVSrJMQZYpV5Q3FAWOAQ8CDwGP+H3eVMca3ib2hUiNUKpV CiWZQqlEviSTL5bOebwCVeBJ4EfAj/w+78lOt7kV7GuRNiOEoFCSyRaK5IpFCsUS6rnvu1fQBPue 3+d9qdPtNYoLSqTNqKpKtlAkncuTyRdQqtWN//0i8B00wVY63dZmuKBF2ogA8sUiqWyeVDa3UTAV CAFfB/7P7/NW93qOTnHRiLQRIQTZQpFkJks6l9/4SFwCvgF80+/zhjvdzp1yUYq0kaqqksxkiaUy lMr1+bIM/AfwpQthsHHRi7SRXKFILJ0hncvrE2wV+CHwN36f92in29eIS0oknXKlQiSZIpHO6o9C Afwv8Bm/z/typ9u3mUtSJB2lWiWaTBNNpfX5lwp8F/grv897utPt07mkRdJRqlUiyRSxZFrvWTLw 98A9fp8311ztzWOKtIGKorAWT5BIZ/U/rQF/Cny/k4Zea6cvzH7CLknMjI1yxewBeru7ASaAAPBg IBia61S7TJHOQ09XF5fNTDE7MYZdsgG8FXgxEAx9IhAMSe1ujynSFgy4XVx5cIah/j6AHuAe4MlA MHRlO9thirQNNquV6bER5g5M0mW3A9wEPB8Ihv4oEAxZmqx+R5gi7RCXs4crZg/ovcoJ/AtwXyAY Gmr1uU2RdoG11qsOTY4j2WwA7wKOBoKhm1t63k5/8QuRflevNgLs6QaYAR4LBEMfadX5TJH2iF2S mDswyciAB6AL+FogGPp6IBiyG30uU6QmsFgsTI0McXBiDKsWVfWHwE8CwdCgkecxRTIAj9vF3PQU dkkCeBvweCAYmjWqflMkg3B2d3H5zBQ9XV0AVwJPBIKha42o2xTJQOySxNz0JC5nD8Ak8EggGLq9 2XpNkQzGZrVyZGoCj6sXwIP2jvqVZuo0RWoBFouF2clxBvvcoC1yuD8QDN291/pMkVqEBZgZH91o obgvEAzdspe6TJFazPTYyMYeFQwEQ2/abR37SqSKopAvlsjmC6SyOTL5PLlCEblc2cnKjH3L9Pgo HrcLYATt0XdwN8e33TeykaIsk8kXyBaKFEry5jjvc7BYLHQ77LicPbidTtzOnvqynP2OBZgdH0VV VTL5wgEgFAiGbvP7vNEdHd9u97kqBPF0hng6Q0k+d91Yl8OOu9eJXZKw2yWqVRVFUcgVSxSKpXN6 k2SzMeB2MTLgwWHv6L22q+9+ammVQqkE2lKet/l93sJ2x7VNJCEEsVSGcCJZDwHuctiZnhhjfGSQ 0cEBurscDY+vVlXiqTTrsQTLaxFSWS0+xGKxMNjnZnxoUPei7muUapXXzixTURSAHwDv3y5+oi23 YKEksxiO1HvOkKefq+cOMjU28obVg42w2ayMDg0wOjTAtVccIZHO8Or8ImdW1omnM6SyOSZGhhjW RlP7Fslm4/DUOCcXV1CFeB/aqsbPbXVMy3tSNJliNZZACIG718mN11zB5OiwYfVn8wWeP/Yaq5EY oLkRZsZHsVn31ZjoDSSzOc6shUFbY/Uuv8/7k0ZlW/ZNBLAUjrISjSOE4IpDM7zzrbcaKhCAu9fJ W2+5nttveBN2SSKdy3NyaUV/nOxbBtwuRjU3hw24NxAMzTQq2xKRBLCwqj2GJJuNO2+6jhuvuaKl d/fs1DjvuOst9Lt7KcnlC0KoiZEh3JqdbxBNqPO+flpy1ZbDUdK5PA67xNtuvZHpidG2fGlXbw/e 229meKCfckXh1NLq5oVl+wrNKjGmu+LvAD5zvnKGixRNpuo96O5bbmB4oL+tX9xht3P3LTfg6XMh VyosrIXZz9Ngu2RjZrx+E3/qfKYjQwcOhZLMyaUVhBDcedN1u+pBkXiS1UiMaCJFNl+orzx32CXc vU6GBzxMjQ0zOjSww7aU+MmjT1OSy4wPDTA+ZKiz1HCWIzFiqTRo636v37j5iGFDcCEEi+FIfZCw E4GEEMwvrfLKqQWy+fPP6UpymZJcJppIcfz1Bdy9Tq6eO8jh6cktLQ7O7m5uu+FNPPTUUcKJFB6X a8t5WKeZHB4kk89TrihXA59kw7DcsJ4UTaZYicZxOXv4jbtv23aQkCsUefz5F4mnMgA4JAlPnwt3 Tw/dXQ4kmw0hBGWlSqVSIVssksrkKNcGA0OePm6/8VrdwdaQZ186zsmFZVw9PcxNT3Zaiy3J5AvM r6yBtqrjer/PexwMeiepQhBOpAB2NIoLx5P89LGniacy2CWJ2fFRrjo8y+TwUN0spG2TY6W7Ziqa HB7iqsOzzI6P4pAk4qkMP33saSLx5Jbnuu7Ky+hyOMgVi2Ty21pgOkpfr5MBzRDbBXxV/7shIsXT GZRqlZFBD1NjI1uWXYvEeeipo8jlCn29Tq48OM1An5ud2B0swECfmysOTtPX60QuV3jwqaOsReIN j3HYJa46osWERJKpFl/m5pkcGdZv8rcHgqH3gIEiAVx5ZOsAmUwuz2PPv4Cqqox4+jk8NbGnuZPN auXw1AQjnn5UVeWx518gk8s3LH/ZwQNIkk1ze1Qqrbq+hmCXbIwO1gdHfxcIhqSmRSrKMiW5THeX gwNb9CIhBE/+/BiKUsXjdjFlgOVhanQYj9uFolR54ufHGvqc7JLEdG2Ym8xkd3OKjjA60K9b9i8H /E2LpD/nD4yPbjnaml9arb+DZrZ5JO6GmbERHJJEIpVhfmm1YbmDUxPntHc/Y7FY6HM69X/+edMi ZQtFAMZHtp6HvHJqAYDJ4SGsBpqHrFYrE8ND55zjfIwMebBarRRLMtWqusPa20+uUOTE4jKx2isE SDZ9tQolGWDjc/QNROJJsvlCfZhtNJ4+Fw67RDZfaDjak2w2Bj19CLRH9H6jrCgsrIU5tbyqX9NV 4MPAXU1NZsuKgqqqdDnsW04UdTeCx+3a0Shut1hqdUcSKVYjsYZWiX5XL7FEilK5vO38ql0IIYgm 06zHE/rK9xzaisIv+33eIjRpcajUTDfuXueW5aK1OZS7hRfG3dNDhBSxRLpxmVo7z7PZYUcoyjKL 61G9Zwvg+8DH/T7v8sZyTYl01g2+tblFN/m00iyj153JNx6K22uxEFW1s+8kAUQSSdbjSX1Eehr4 sN/nDZ2vfFMi6btfbRdboN+5NZN8S9Dr3qqX1FY9bBmV1GrKisKZtTD5Ygk0vb4KfMrv8za8u5oS qbYmZ1+PljZSrfV8I0eXuyFXKLKwFtafQKvAB/0+78+2O66p1upftryNB1QPuWqlA06ve6vwroqi i9T+eL1IMsXrK2t6O+8Hrt2JQNCkSI7a4yO3zQRRf2FvjrMzEr3uvt7ehmUKRW1OZ7e1L05PVVXO rIVZ1WI9BPB5wOf3eeM7raOp1jrsmrW6UJJRqtWG75zhAY/mzCsWtx0J7pVsTYDhwcae4ExOu5m6 HIYvaz0vFaXK/MoqRe0GygC/4/d579ttPU31JD30VwhBIpVpWG5qTLPTpTK5lriyBdSDJRtFIwkh iGueT3ra4PyTyxVOLi3rAr0KvHkvAoEBVnBXjzb3WY8lGpYZHRrA3eukrCikMsbvTJbK5ihXFNy9 TkYGPQ3LyOUKDruEw97anqSHEdRGmk8Ct/t93tf2Wl/TIumPr5X1rWPPr547CMBqLG7oEFhVVdai 8fo5Ghl5l1a17AluZ2setzrZQpFTy/UopR8Dv+r3eRPN1Nm8SM4eJJuNZCa7pRvg8PQkg54+KorC YnhHiwl2xGI4SllRGOzv43AD97gQgtOaW1r3fLaEXKHI6ZU1/Sb8DvCenQTkb0fTIlksFgZqRtPX 5he3LHfb9dcgSTZS2RwrNXteM6xEYqSyOSTJxm03XNOwF62EY+QLRRx2qWU2u3yxxPzquj7B/ze0 OZAhHkZDZnUjHg8Wi4WFlTVy+WLDcn2uXu648VqsVivRVJr5lbU9mWhUVWV+ZY1oKo3VauWOG6+l z9V46H3sxHytna2JASyUSsyf7UHfQjPxGDZGMkQkh11ioM+FqgqOvrL1+3FydJi7br4OSbKRyRd4 bWGJZHZnoz6BFuj+6sISmXwBSbJx183XbRlffmpxhURaczYOtUAkuVJhfmVdv9nuBf7A6K1ADZvV TQwNkc7mWV6PcmZ1ndnJ8YZlJ0eH+fU7b+GJo8dIpDOcWQuzFo1rIV3OHrodjvqcS6lWKZXLZAvF +igOYLC/j9tuuGbLHlQsybxwXNubfXJkqG7GMgqlWmV+uW5FuA/tEWe4WcUwkeySjYmRIZbDUZ55 8ThDnv4tn/99rl5+7c43M7+0ysunTpPLF4kkUkRqbo1GuHp7+KW5Q9sGRwohePzoS8jlCm6n0/AB gxCC+ZV1PbDlaeC3WpUHw1D7yHB/H9l8gXQuz6PP/oK333rTlrN7i8XCkZkpDk9PEk2kWAlHiSbT 5DaFGbt6nYwM9DM1NsLIoGdHa2WfO/YqkXgSu2RjtgULBpYjMX1Z5TyamadlwROGG7Fmxkc5ubhC KpPj4Wd+zt233LDtmlaLxVJfxWcEL7x6ipMLy9qmFxNjhrtIEpmsHsZWAN670wXKe8Vwm70eE2eX JOLJND974lmKpfbEFAgheObF47x88nR9xbduETGKolxm+ew873f9Pu+Lrf5eLXGsOOwSl01P0e2w k8rk+PGjTxGONTXp3pZiSeahp45y6swyVouFg5Pj+t4JhpLJF/S50CN+n/cHLf1SNVrm/XLYJeam p3A5eyjJZR586ijPvnTc8PgCIQSnFle4/5EnWY8lsEs2jhyYpH+LUV8zbNg/4q5AMPTuVl2/jbR8 YbMAwvEE4UQKIQRdDjtXzx1ibra+id/e6hWC5fUox07Ok6ylLXD3OpkZG235VgGxVIblSBS0FKtv 9vu8J1p5vrbt41CUZZYjMd23jyTZmJkYY3ZynJEhz45e7kIIUtkcS2sRTi+t1uuySzYmhof0PXza wpn1MEnNov8KcJvf5003WWVD2r4jSrZQJJxIkiucNR9ZrVaGPH30uXpx9zpx2CXskoRSrVJRqhSK JdK5HIlUBrl81hzmsEuMDngY7O8zfKK6HaoQnFhc1j3CDwLvaFVq8I5lfZErFZKZLJl8gWJJ3rEz 0CFpyzMH3K6OBzhWFIUTi/VV7veieV4N92t2bFOeLrud8aFBxocGqVZVCrKMXC5Trij1HOpWqxWr 1YJks9Flt+Ps7mq5w2432CWJI1MTnFxaoaqqHwBiwMeMPo+ZP8kAcoUir6+s6YGOX/L7vB83sv79 vbfLBYLL2cOhyXF9aP5ngWDos0bWb4pkEH29TmYnxvQFCX8ZCIbuMSorjCmSgXhcvZpQWo/6BPDN QDDU9KTNFMlgPG4XB88K9SHgh4FgqLuZOk2RWkC/q5cjZxdtvxt4IBAM7dlfYorUIlzOHi47m7/i TuC5QDB0017qMkVqId1dDi6fmcLZ3QUwjZZn6YO7rccUqcVo+Sum9LC3buDbgWDonwLB0I5jnU2R 2oDVYmF2fIwDo8P6gOKjwDOBYOi6HR3f6S9wKTHs6eey6Sk9y+Z1aEJ9arvctaZIbcbZ3cXlswd0 t4oD+Gvg0UAwdFmjY0yROoDNamVmfJRDk+O6g/JW4BeBYOjTgWCoa3N5U6QO0u/q5crZGb1XOYEv AMcCwZBvYzlTpA5js2m9au7ApL7NwRxaGp+HA8HQW8B0VewrRC2Px3q8nipCAN8ye9I+wmKxMOzp 56pDM3pYtAV4pynSPsRmtW7cduErpkj7kEy+oEdCxYCvmSLtM4QQrEbrqyA/5/d5c6ZI+4xoKk1J C1t7Ffg6mEPwfUW5UmH97KaKH/P7vAqYIu0rliIxfd3tf/p93p/qfzdF2ickMll9X8AEm2L3TJH2 ARVF2bhlwkf9Pu/6xv83ReowAjizHtFXrwf8Pm9gcxlTpA4TjtcXLywAHzlfGVOkDpIrFAnHE6Al X/ztRstnTJE6RKW2D3htCcZf+H3exxuVNUXqAKoQnF5d1y3dPwD+dqvypkgdYHE9ou+i/wLaCvYt 1zSZIrWZtVhc3+UyirYHxLabdJgitREt93sKoIiW8/z0To4zRWoT2h5/UdBGcu/3+7wP7vRYU6Q2 kMkXOLMeQWhz19/f7Ya5pkgtJlsosrC6ri/V/ITf5/32buvo2MLmS4FMvsDC2S0/v+j3eb+0l3rM ntQi0rk8p88K9Fm/z/vpvdZl9qQWkMhkWQpH9bQHf+L3eb/STH2mSAYTSaRYjcVBG8V92O/z/nuz dZoiGYQQguVITN+ssAx8wO/z/pcRdZsiGUC1qnJ6bV13OaSB9/l93geMqt8UqUmKsszCaljfMPd1 tF31XzbyHKZITZDIZFkOR/UR3KPAb/p93uZTB2zCFGkPqKrKcjRGQtsMUQBfBj6ph2AZjSnSLimU ZM6sh/V99zLAh/w+73+38pymSDtECEEkmdqYdvQpNJf3660+tynSDtiUtFcBvgh8vlWPt82YIm2B KgTr8QTRZFrvPceB3/P7vE+2sx2mSA1IZnOsReP6OqEK8HfAF/w+b6ndbTFF2kRRllmJxjdu5Psw 8Md+n/elTrXJFKmGXFvRsCHl3RLannXfb8Xmt7vhkhepoiiE40nimaz+3skB/wjc4/d5jU/luQcu WZHkcoVIMkXirDhl4Btozrn15mo3lktOpEJJJpJM1ZMHo4kTQHPMLXS6fefjkhBJFYJUJkcsndaD EgHywDeBf/D7vEudbuNWXNQiFWWZRCZLIpOlWq1n4VwD/hX451YYQ1vBRSeSnro7kclSKp+TOuJh tIXC/2NU/td2cVGIVCpXyOTypPP5eiaYGqvA94BvGe3jaScXpEiqEOSLJS3JYz5/TiYYtCH0D4Hv Ag+2KmNlO7kgRFKFoFiSyRaK5ApF8qWSPmzWCaPleb0P+FknTDetZN+JJISgVC5TKMn1T6lc3iyK AjyHlrfofuBJv8+7+/zcFwgdE6miVKkoFeSyglwpUypXKMll5EplsyCgGThfQHNRP4SW9DC723Ne qNRFitWSvdusVmy22k+rFYvFgtVSC3S1oO8ajxACVT17MatqFSGgqqr1/EfVqopSrdYyiimUFYWK olBRqucTol4VcAKtpzxb+/ziYnuE7QYJkIGu5UjbpwzrwDJaxuMTwGto+fFeuZQFOR8S8F60bfr7 a5++Db+7gS60/UEBbLX/B0huqEf/XUWLO0uj+f9TaNuBhWufRTRhlv0+b3syBF8E/D/9MznAcFKe sQAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOS0wNy0xOVQxNzoyMTo1NiswODowMH2ndbkAAAAldEVY dGRhdGU6bW9kaWZ5ADIwMTktMDctMTlUMTc6MjE6NTYrMDg6MDAM+s0FAAAAGXRFWHRTb2Z0d2Fy ZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAABJRU5ErkJggg=="
      });

      defs.selectAll("marker#fishHead")
      .data([1])
      .enter().append("marker")
        .attr({
          id: 'fishHead',
          refX: 0,
          refY: 25,
          markerWidth: 63,
          markerHeight: 87,
          orient: "auto"
        })
      .append("svg")
        .attr({
        version: "1.1",
        id:"Layer_1",
        xmlns:"http://www.w3.org/2000/svg",
        xlink:"http://www.w3.org/1999/xlink",
        x:"0px",
        y:"0px",
        width:"63px",
        height:"87px",
        viewBox:"0 0 105 145",
        enableBackground:"new 0 0 105 145",
        xml:"preserve"
      })
      .append("image").attr({
        id:"image0",
        width:"63",
        height:"87",
        x:"0",
        y:"0",
        href:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAACRCAYAAADAQ5ZOAAAABGdBTUEAALGPC/xhBQAAACBjSFJN AAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAA B3RJTUUH4wcUARU4Lyrr6QAAFmJJREFUeNrtnXmQI1d9xz+SWpoZjTSjua+dmT3GZ4wdXxifwRBV AkFQVKooIpKiQpIioYoUlVSAQEiFI8QJCUVCCEVCCipgQaiEBCtlwKJ8lm97wfbaa++uZ2fn1n0f LbX65Y9Wa2fHq7nUkmZ3+1OlmtnZ16+f+tuv+73f7/fezyKEIBAMdQN9QH/t50DtdzfgQMMOuDiX CpDb9HsBSNY+KSDp93lLmOwZy733PfAYcEeLz1ME1oFlYBFYqf1+BjgJvO73ecudvhj7Fcu99z0g ACSbDZvVis1mxWa1YrVqPy0Wi1bQYsFqtZxzsBCgqmr931VVRVVVqqpKtapSVasoVRUhxHbtUIB5 4GXg1drP54ATfp9324Mvduoi/fLlR1p2ElUIKhWFSlWhXFGoKNqnXFGQyxXKlQoNlEgDzwPPAk8D j/t93kinL1q7aYtI2yGEoFSuIJfLlMoVSrJMQZYpV5Q3FAWOAQ8CDwGP+H3eVMca3ib2hUiNUKpV CiWZQqlEviSTL5bOebwCVeBJ4EfAj/w+78lOt7kV7GuRNiOEoFCSyRaK5IpFCsUS6rnvu1fQBPue 3+d9qdPtNYoLSqTNqKpKtlAkncuTyRdQqtWN//0i8B00wVY63dZmuKBF2ogA8sUiqWyeVDa3UTAV CAFfB/7P7/NW93qOTnHRiLQRIQTZQpFkJks6l9/4SFwCvgF80+/zhjvdzp1yUYq0kaqqksxkiaUy lMr1+bIM/AfwpQthsHHRi7SRXKFILJ0hncvrE2wV+CHwN36f92in29eIS0oknXKlQiSZIpHO6o9C Afwv8Bm/z/typ9u3mUtSJB2lWiWaTBNNpfX5lwp8F/grv897utPt07mkRdJRqlUiyRSxZFrvWTLw 98A9fp8311ztzWOKtIGKorAWT5BIZ/U/rQF/Cny/k4Zea6cvzH7CLknMjI1yxewBeru7ASaAAPBg IBia61S7TJHOQ09XF5fNTDE7MYZdsgG8FXgxEAx9IhAMSe1ujynSFgy4XVx5cIah/j6AHuAe4MlA MHRlO9thirQNNquV6bER5g5M0mW3A9wEPB8Ihv4oEAxZmqx+R5gi7RCXs4crZg/ovcoJ/AtwXyAY Gmr1uU2RdoG11qsOTY4j2WwA7wKOBoKhm1t63k5/8QuRflevNgLs6QaYAR4LBEMfadX5TJH2iF2S mDswyciAB6AL+FogGPp6IBiyG30uU6QmsFgsTI0McXBiDKsWVfWHwE8CwdCgkecxRTIAj9vF3PQU dkkCeBvweCAYmjWqflMkg3B2d3H5zBQ9XV0AVwJPBIKha42o2xTJQOySxNz0JC5nD8Ak8EggGLq9 2XpNkQzGZrVyZGoCj6sXwIP2jvqVZuo0RWoBFouF2clxBvvcoC1yuD8QDN291/pMkVqEBZgZH91o obgvEAzdspe6TJFazPTYyMYeFQwEQ2/abR37SqSKopAvlsjmC6SyOTL5PLlCEblc2cnKjH3L9Pgo HrcLYATt0XdwN8e33TeykaIsk8kXyBaKFEry5jjvc7BYLHQ77LicPbidTtzOnvqynP2OBZgdH0VV VTL5wgEgFAiGbvP7vNEdHd9u97kqBPF0hng6Q0k+d91Yl8OOu9eJXZKw2yWqVRVFUcgVSxSKpXN6 k2SzMeB2MTLgwWHv6L22q+9+ammVQqkE2lKet/l93sJ2x7VNJCEEsVSGcCJZDwHuctiZnhhjfGSQ 0cEBurscDY+vVlXiqTTrsQTLaxFSWS0+xGKxMNjnZnxoUPei7muUapXXzixTURSAHwDv3y5+oi23 YKEksxiO1HvOkKefq+cOMjU28obVg42w2ayMDg0wOjTAtVccIZHO8Or8ImdW1omnM6SyOSZGhhjW RlP7Fslm4/DUOCcXV1CFeB/aqsbPbXVMy3tSNJliNZZACIG718mN11zB5OiwYfVn8wWeP/Yaq5EY oLkRZsZHsVn31ZjoDSSzOc6shUFbY/Uuv8/7k0ZlW/ZNBLAUjrISjSOE4IpDM7zzrbcaKhCAu9fJ W2+5nttveBN2SSKdy3NyaUV/nOxbBtwuRjU3hw24NxAMzTQq2xKRBLCwqj2GJJuNO2+6jhuvuaKl d/fs1DjvuOst9Lt7KcnlC0KoiZEh3JqdbxBNqPO+flpy1ZbDUdK5PA67xNtuvZHpidG2fGlXbw/e 229meKCfckXh1NLq5oVl+wrNKjGmu+LvAD5zvnKGixRNpuo96O5bbmB4oL+tX9xht3P3LTfg6XMh VyosrIXZz9Ngu2RjZrx+E3/qfKYjQwcOhZLMyaUVhBDcedN1u+pBkXiS1UiMaCJFNl+orzx32CXc vU6GBzxMjQ0zOjSww7aU+MmjT1OSy4wPDTA+ZKiz1HCWIzFiqTRo636v37j5iGFDcCEEi+FIfZCw E4GEEMwvrfLKqQWy+fPP6UpymZJcJppIcfz1Bdy9Tq6eO8jh6cktLQ7O7m5uu+FNPPTUUcKJFB6X a8t5WKeZHB4kk89TrihXA59kw7DcsJ4UTaZYicZxOXv4jbtv23aQkCsUefz5F4mnMgA4JAlPnwt3 Tw/dXQ4kmw0hBGWlSqVSIVssksrkKNcGA0OePm6/8VrdwdaQZ186zsmFZVw9PcxNT3Zaiy3J5AvM r6yBtqrjer/PexwMeiepQhBOpAB2NIoLx5P89LGniacy2CWJ2fFRrjo8y+TwUN0spG2TY6W7Ziqa HB7iqsOzzI6P4pAk4qkMP33saSLx5Jbnuu7Ky+hyOMgVi2Ty21pgOkpfr5MBzRDbBXxV/7shIsXT GZRqlZFBD1NjI1uWXYvEeeipo8jlCn29Tq48OM1An5ud2B0swECfmysOTtPX60QuV3jwqaOsReIN j3HYJa46osWERJKpFl/m5pkcGdZv8rcHgqH3gIEiAVx5ZOsAmUwuz2PPv4Cqqox4+jk8NbGnuZPN auXw1AQjnn5UVeWx518gk8s3LH/ZwQNIkk1ze1Qqrbq+hmCXbIwO1gdHfxcIhqSmRSrKMiW5THeX gwNb9CIhBE/+/BiKUsXjdjFlgOVhanQYj9uFolR54ufHGvqc7JLEdG2Ym8xkd3OKjjA60K9b9i8H /E2LpD/nD4yPbjnaml9arb+DZrZ5JO6GmbERHJJEIpVhfmm1YbmDUxPntHc/Y7FY6HM69X/+edMi ZQtFAMZHtp6HvHJqAYDJ4SGsBpqHrFYrE8ND55zjfIwMebBarRRLMtWqusPa20+uUOTE4jKx2isE SDZ9tQolGWDjc/QNROJJsvlCfZhtNJ4+Fw67RDZfaDjak2w2Bj19CLRH9H6jrCgsrIU5tbyqX9NV 4MPAXU1NZsuKgqqqdDnsW04UdTeCx+3a0Shut1hqdUcSKVYjsYZWiX5XL7FEilK5vO38ql0IIYgm 06zHE/rK9xzaisIv+33eIjRpcajUTDfuXueW5aK1OZS7hRfG3dNDhBSxRLpxmVo7z7PZYUcoyjKL 61G9Zwvg+8DH/T7v8sZyTYl01g2+tblFN/m00iyj153JNx6K22uxEFW1s+8kAUQSSdbjSX1Eehr4 sN/nDZ2vfFMi6btfbRdboN+5NZN8S9Dr3qqX1FY9bBmV1GrKisKZtTD5Ygk0vb4KfMrv8za8u5oS qbYmZ1+PljZSrfV8I0eXuyFXKLKwFtafQKvAB/0+78+2O66p1upftryNB1QPuWqlA06ve6vwroqi i9T+eL1IMsXrK2t6O+8Hrt2JQNCkSI7a4yO3zQRRf2FvjrMzEr3uvt7ehmUKRW1OZ7e1L05PVVXO rIVZ1WI9BPB5wOf3eeM7raOp1jrsmrW6UJJRqtWG75zhAY/mzCsWtx0J7pVsTYDhwcae4ExOu5m6 HIYvaz0vFaXK/MoqRe0GygC/4/d579ttPU31JD30VwhBIpVpWG5qTLPTpTK5lriyBdSDJRtFIwkh iGueT3ra4PyTyxVOLi3rAr0KvHkvAoEBVnBXjzb3WY8lGpYZHRrA3eukrCikMsbvTJbK5ihXFNy9 TkYGPQ3LyOUKDruEw97anqSHEdRGmk8Ct/t93tf2Wl/TIumPr5X1rWPPr547CMBqLG7oEFhVVdai 8fo5Ghl5l1a17AluZ2setzrZQpFTy/UopR8Dv+r3eRPN1Nm8SM4eJJuNZCa7pRvg8PQkg54+KorC YnhHiwl2xGI4SllRGOzv43AD97gQgtOaW1r3fLaEXKHI6ZU1/Sb8DvCenQTkb0fTIlksFgZqRtPX 5he3LHfb9dcgSTZS2RwrNXteM6xEYqSyOSTJxm03XNOwF62EY+QLRRx2qWU2u3yxxPzquj7B/ze0 OZAhHkZDZnUjHg8Wi4WFlTVy+WLDcn2uXu648VqsVivRVJr5lbU9mWhUVWV+ZY1oKo3VauWOG6+l z9V46H3sxHytna2JASyUSsyf7UHfQjPxGDZGMkQkh11ioM+FqgqOvrL1+3FydJi7br4OSbKRyRd4 bWGJZHZnoz6BFuj+6sISmXwBSbJx183XbRlffmpxhURaczYOtUAkuVJhfmVdv9nuBf7A6K1ADZvV TQwNkc7mWV6PcmZ1ndnJ8YZlJ0eH+fU7b+GJo8dIpDOcWQuzFo1rIV3OHrodjvqcS6lWKZXLZAvF +igOYLC/j9tuuGbLHlQsybxwXNubfXJkqG7GMgqlWmV+uW5FuA/tEWe4WcUwkeySjYmRIZbDUZ55 8ThDnv4tn/99rl5+7c43M7+0ysunTpPLF4kkUkRqbo1GuHp7+KW5Q9sGRwohePzoS8jlCm6n0/AB gxCC+ZV1PbDlaeC3WpUHw1D7yHB/H9l8gXQuz6PP/oK333rTlrN7i8XCkZkpDk9PEk2kWAlHiSbT 5DaFGbt6nYwM9DM1NsLIoGdHa2WfO/YqkXgSu2RjtgULBpYjMX1Z5TyamadlwROGG7Fmxkc5ubhC KpPj4Wd+zt233LDtmlaLxVJfxWcEL7x6ipMLy9qmFxNjhrtIEpmsHsZWAN670wXKe8Vwm70eE2eX JOLJND974lmKpfbEFAgheObF47x88nR9xbduETGKolxm+ew873f9Pu+Lrf5eLXGsOOwSl01P0e2w k8rk+PGjTxGONTXp3pZiSeahp45y6swyVouFg5Pj+t4JhpLJF/S50CN+n/cHLf1SNVrm/XLYJeam p3A5eyjJZR586ijPvnTc8PgCIQSnFle4/5EnWY8lsEs2jhyYpH+LUV8zbNg/4q5AMPTuVl2/jbR8 YbMAwvEE4UQKIQRdDjtXzx1ibra+id/e6hWC5fUox07Ok6ylLXD3OpkZG235VgGxVIblSBS0FKtv 9vu8J1p5vrbt41CUZZYjMd23jyTZmJkYY3ZynJEhz45e7kIIUtkcS2sRTi+t1uuySzYmhof0PXza wpn1MEnNov8KcJvf5003WWVD2r4jSrZQJJxIkiucNR9ZrVaGPH30uXpx9zpx2CXskoRSrVJRqhSK JdK5HIlUBrl81hzmsEuMDngY7O8zfKK6HaoQnFhc1j3CDwLvaFVq8I5lfZErFZKZLJl8gWJJ3rEz 0CFpyzMH3K6OBzhWFIUTi/VV7veieV4N92t2bFOeLrud8aFBxocGqVZVCrKMXC5Trij1HOpWqxWr 1YJks9Flt+Ps7mq5w2432CWJI1MTnFxaoaqqHwBiwMeMPo+ZP8kAcoUir6+s6YGOX/L7vB83sv79 vbfLBYLL2cOhyXF9aP5ngWDos0bWb4pkEH29TmYnxvQFCX8ZCIbuMSorjCmSgXhcvZpQWo/6BPDN QDDU9KTNFMlgPG4XB88K9SHgh4FgqLuZOk2RWkC/q5cjZxdtvxt4IBAM7dlfYorUIlzOHi47m7/i TuC5QDB0017qMkVqId1dDi6fmcLZ3QUwjZZn6YO7rccUqcVo+Sum9LC3buDbgWDonwLB0I5jnU2R 2oDVYmF2fIwDo8P6gOKjwDOBYOi6HR3f6S9wKTHs6eey6Sk9y+Z1aEJ9arvctaZIbcbZ3cXlswd0 t4oD+Gvg0UAwdFmjY0yROoDNamVmfJRDk+O6g/JW4BeBYOjTgWCoa3N5U6QO0u/q5crZGb1XOYEv AMcCwZBvYzlTpA5js2m9au7ApL7NwRxaGp+HA8HQW8B0VewrRC2Px3q8nipCAN8ye9I+wmKxMOzp 56pDM3pYtAV4pynSPsRmtW7cduErpkj7kEy+oEdCxYCvmSLtM4QQrEbrqyA/5/d5c6ZI+4xoKk1J C1t7Ffg6mEPwfUW5UmH97KaKH/P7vAqYIu0rliIxfd3tf/p93p/qfzdF2ickMll9X8AEm2L3TJH2 ARVF2bhlwkf9Pu/6xv83ReowAjizHtFXrwf8Pm9gcxlTpA4TjtcXLywAHzlfGVOkDpIrFAnHE6Al X/ztRstnTJE6RKW2D3htCcZf+H3exxuVNUXqAKoQnF5d1y3dPwD+dqvypkgdYHE9ou+i/wLaCvYt 1zSZIrWZtVhc3+UyirYHxLabdJgitREt93sKoIiW8/z0To4zRWoT2h5/UdBGcu/3+7wP7vRYU6Q2 kMkXOLMeQWhz19/f7Ya5pkgtJlsosrC6ri/V/ITf5/32buvo2MLmS4FMvsDC2S0/v+j3eb+0l3rM ntQi0rk8p88K9Fm/z/vpvdZl9qQWkMhkWQpH9bQHf+L3eb/STH2mSAYTSaRYjcVBG8V92O/z/nuz dZoiGYQQguVITN+ssAx8wO/z/pcRdZsiGUC1qnJ6bV13OaSB9/l93geMqt8UqUmKsszCaljfMPd1 tF31XzbyHKZITZDIZFkOR/UR3KPAb/p93uZTB2zCFGkPqKrKcjRGQtsMUQBfBj6ph2AZjSnSLimU ZM6sh/V99zLAh/w+73+38pymSDtECEEkmdqYdvQpNJf3660+tynSDtiUtFcBvgh8vlWPt82YIm2B KgTr8QTRZFrvPceB3/P7vE+2sx2mSA1IZnOsReP6OqEK8HfAF/w+b6ndbTFF2kRRllmJxjdu5Psw 8Md+n/elTrXJFKmGXFvRsCHl3RLannXfb8Xmt7vhkhepoiiE40nimaz+3skB/wjc4/d5jU/luQcu WZHkcoVIMkXirDhl4Btozrn15mo3lktOpEJJJpJM1ZMHo4kTQHPMLXS6fefjkhBJFYJUJkcsndaD EgHywDeBf/D7vEudbuNWXNQiFWWZRCZLIpOlWq1n4VwD/hX451YYQ1vBRSeSnro7kclSKp+TOuJh tIXC/2NU/td2cVGIVCpXyOTypPP5eiaYGqvA94BvGe3jaScXpEiqEOSLJS3JYz5/TiYYtCH0D4Hv Ag+2KmNlO7kgRFKFoFiSyRaK5ApF8qWSPmzWCaPleb0P+FknTDetZN+JJISgVC5TKMn1T6lc3iyK AjyHlrfofuBJv8+7+/zcFwgdE6miVKkoFeSyglwpUypXKMll5EplsyCgGThfQHNRP4SW9DC723Ne qNRFitWSvdusVmy22k+rFYvFgtVSC3S1oO8ajxACVT17MatqFSGgqqr1/EfVqopSrdYyiimUFYWK olBRqucTol4VcAKtpzxb+/ziYnuE7QYJkIGu5UjbpwzrwDJaxuMTwGto+fFeuZQFOR8S8F60bfr7 a5++Db+7gS60/UEBbLX/B0huqEf/XUWLO0uj+f9TaNuBhWufRTRhlv0+b3syBF8E/D/9MznAcFKe sQAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOS0wNy0xOVQxNzoyMTo1NiswODowMH2ndbkAAAAldEVY dGRhdGU6bW9kaWZ5ADIwMTktMDctMTlUMTc6MjE6NTYrMDg6MDAM+s0FAAAAGXRFWHRTb2Z0d2Fy ZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAABJRU5ErkJggg=="
      });

      defs.selectAll("marker#fishTail")
        .data([1])
      .enter().append("marker")
        .attr({
          id: 'fishTail',
          refX: 36,
          refY: 25,
          markerWidth: 63,
          markerHeight: 87,
          orient: "auto"
        })
      .append("svg")
        .attr({
        version: "1.1",
        id:"Layer_1",
        xmlns:"http://www.w3.org/2000/svg",
        xlink:"http://www.w3.org/1999/xlink",
        x:"0px",
        y:"0px",
        width:"63px",
        height:"87px",
        viewBox:"0 0 105 145",
        enableBackground:"new 0 0 105 145",
        xml:"preserve"
      })
      .append("image").attr({
        id:"image0",
        width:"63",
        height:"87",
        x:"0",
        y:"0",
        href:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAE0AAAB0CAYAAADAfL/VAAAABGdBTUEAALGPC/xhBQAAACBjSFJN AAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAA B3RJTUUH4wcUARYe1go91wAADV9JREFUeNrlnXlsHNd9xz9z8FiSS3JJriiSkihKglLIcqL+Ebhu WsAtMC2CYhDADZx0AANN0jiH/0iaBs2FAm2QOu0/dQI7iYv0CApokMauE2hc1NE4dl0YbRzHsXwk 8SVLNGmJ4rVL7r07R/+YmeWQ4rE89v4ACw65M7M7X76Z997veoLruuiGGQMmgDEgDgz6r36gD+jA I9jOAEX/bykg6/9cApaBBeAdYE5TlTwthnD+wsUHgXur+BnXgavAFeDXwOvAy8DrmqrY9RZgLwjn L1x0Abo7O5BlmQ5JQpJEJFFCEkVEUUAQBABEUUQAHNfFdV0AbNvBcR1s28F2HCzbwbZtipaFZVm4 W392DngJeNZ/PaOpytv1FqRS0dJA77tPTSGK4oGe3HVdLNumWLIolErki0UKxRL5QpFCqbTZIW8B /w1cBC5qqpKot0BbiZYEBm49NYV0wKJth+O65PIFMvk8mZz3sux1d6sFPA08DDyqqcpCvcUKi7YI DJ89eRxZkur6ZQrFEqlsjpVMhnQ2V34EADbwY+B7wAVNVQr1Fm0aOHZmapLODrmuooWxHYdUJstK JsNqJottO8FbS8A/Ad+u1zNQOH/h4gvAuXdNHiHS1VVvrTbFdV1W0hmWV1OsZrLBny3gEeA+TVVe ruX3EfHGVVhr/8mGQxAEBqN9nJgY48zUMeKxQSRRlIEPA5d0w/wP3TDP1Or7iEACwLabY8jU2dHB RHyYW05MMjYyhCxJInAn8KJumN/WDXOs2t9BBBaBjT1XwyOKIqNDMc5MHWNsZAjRa3mfAn6tG+an dcOs2lBABN4GKFpWvXXY2wWExBsZ6AcYAL4FPKMb5m9U5TOBaYBSqTlFC5AliSOjcU4fmyDS1Qlw O/C8bpifOOjPKotWbHLRAnq6uzl97AijQzEE6AEe8juKvoP6DBFvMr3VtKYpEQSBsZEhTh2doFOW weso/k83zJMHcX5RU5VZIGXZNiWruTqDneiNdHN68gh9kQjAWeBnumHevt/zBj3MLwHyxeI+TtWY yJLEySNjDHudxBDwhG6Y79/POQPRXgTIF+o6pasagiBwdDTO4eEYeM+5H+mG+YG9ni8Q7TmAbL41 RQs4PDzERHwEoBP4gW6Yf7CX8wSi/S9AOtdylumbiMcGGI8PgyfcD3XDvG235whEexVYLlkWpSYd 5O6GQ7FBRofKt+oF3TCP7OZ4EUBTFRd4BiCdbf3WBjA2MkQs2gdwCHhMN8yeSo8Nz89MgNVMpt7X UzOOHj5ET3c3wHuABys9LizafwGksrl6X0vNEAWB4+OjeIYSPqIb5l0VHRdsaKpyGXjVsm0ybdAh BHTKMkcPxYNfH9INc2KnYzaaT34EkEyn630tNWUw2sdQfxQgBnxzp/03ivbvAMlUe4kGMB4fDhxL f7zTjGGdaJqqXAJ+VbLstnq2gTfdGh8ZDn59QDfMjq323cy6+W8ASyur9b6OmjM0EKWnuwvgJPBn W+23mWj/AhRX0pmWs3pUwthaa/uKbpiRzfa5STTfk/2I67osr7Zfa4v2RAJT0gSez+EmtnI+fANg IbGC424TwtKi+NYQgM/ohnmTB31T0TRVeQ54wrJtlpLt19r6eiJ0e36GY3hW33Vs5+a6D+DGcgLH aVxHcrWIDw4Em5/c+N6Wommq8hTwE8u2mU+s1Psaak6sPxpEUd2hG+ZU+L2dHKpfANyFRLLtelJR EBjo6wUQgLvXvbfdgZqqPA+ctx2H64tL9b6OmhPzplYA6ybylbjuPw8kl1dTbTdL6OuJ0CFLALeE vfU7iqapyg3gywAzN+ax26hTEIBoT9k2+UfBRqVBIg8BTxZLFu/ML9b7WmpKtLcsWtkJU5Fovjn8 T/Fv08Rq+1hBoj3lmdTv6IbZCZW3NDRVmQE+Drgz8wst6VjeDFmSggjRHuAc7EI0AE1VHgG+4TgO V96Za7qYtr3iWz4A3gu7FM3nC8CThVKJK9fm2mJuum/RNFUp4c3HXsnk8kxfvxEOXW9JQqLdBiDs 9YJ9B+vTwInBaB+TY6MI9b66KuG6Li+9eQXXdS0gsue4VD9E6/eBq8lUuqVbnCAIdHV0AMjA8X0F 82qqMo0n3Ewyleata3MtaxHp6iy7DE7vOwJaU5UrwB3AG6lMljdmrrVkPEgom+fUgYSNa6ryFvBb wNO5QoHXpmdJ51prnuqHoQIcO7BYe01VlvGmGt+zbJvLM9e4vrjcMs85eU204T33ntuhG+afA38P dPR0dzE5Nho8SJuWdDbHm7PXAB6vSlaHpir3A+8D3sjmC7x2dYb55WRTtzo/SAZgpGqpML5z5hzw Tcd1rWuLS7w2PRvOomsqJLGcCztSldtzI7ph/ibwHfwRdW+km8PDQ2ELQsNj2TavXL4KsFCT/GtN VV4Afhv4GDCTyeW5PHuN16ZnWVpZbYr5ayi/v7MmLS2MbphdeG6xLwKHwXteDPVHiUWj4Xlew3Hp 9csAbs1FC/DF+xPgs3jhmwD0RSKcOjpeb302xRdtT6ahg8LBS6leN31wafxbteaZ/r7J+OPAl/CC TJAliVh/lFi0r6FvT5/VmommG6aAdzt+DZgCz04VHxxkMNpbrjLTqIQ6K7cmoumGeQvekON3oTmH HCHrTaqqovkP+78BPgd0BEn7vru/qXCctcIqVRNNN8x3A+eBs4IgeKk1wzHEBr8Nt8J2yk6kRFVE 0w3zHrzQ8u5IVxeTY4fo7uys93Xvi1AFmoMVze8ZHwDuAYjHBhkfGWr4h3wlhNyVCwcmml/t71Hg DkkSmTw8Sn9vxTlaDU8o1OydAxHNT415HDjb3dnB1MRY09vPNhKqWzKzb9H8MjVPAqd7I92cGB8L 255ahuJaNYk39iWabphx4AngdLS3h6nxw03bO+5E4SBE0w1zBPgJcKbfF6wVHvib4eIVxMMrfndl T/eRn4X7GHBrX0+E4y0sGEChWAxM9W9pqlLctWj+HPJfgdu6uzpb+pYMCFWR+DnszTT0JeAuWZI4 OTFW0+Kb9SIk2s9gl6Lphvl7wFcFQWBq4jAdcuPUkKwm2Xw50/o52IVoumEO4c0lpYn4ML1ewnzL YzsOuUIRoAC8ALtrad8Bxvp7exlZS4FpeUKlY5/VVCULFYqmG+YH8Z9jR0fjlRzSMqSyZT+tGWzs KJpumFH8VMaJQyNBMkLbEHJu/2ewUUlL+yowEe2JBBVT2oZMPh9UMLwCXAr+vq1ofmW7ewVB4Mih 9rotAZJr+RIP+7kUwM4t7W+BjpHB/nAkYFvgum64Pokefm9L0XTDPAfcFZREbTdChQ9+oanKi+H3 tmtpXwSE+OBA3avH14PFtRIb/7jxvU1F0w3zFPBBURSJx9pnTBaQKxRIe2maCTbcmrB1S/sMIA33 R9uyld1YTgab39JU5absuZtE84vo3g201cg/IFcoBrWWVvHHpxvZrKV9GBiI9kTarscEmFtaDjbv 11Rl0xz0zUT7CBDUhW0rUtkcK+kMeKtr3L/VfutE0w1zErhdEkX6mzB0YD+4rsvsfHntm69oqrJl XY2NLe1DgDDQ19vy1tiNzCeSgR/gWeC72+27UbQ7watc105k8wXmlhLgBRh+SlOVbRO8yqLphnkI eK8oCE0VArVfHMdheq6cQfjXflD1toRbmgKIfT2RlvYsbWTmxkJwW/4P8HeVHBMW7f1AS8Vf7MT8 cpKENyZbAO6udEHDsGjvA6/qSTuwks4EpYCKwJ27WbhLhHJq9XFJEps+jqwS0tmclwnt/fppTVWe 2c3xQUu7HWgLD1Mml/cyoL0H/5c1Vfnn3Z4jcFzeBgR1rFuWdDYXThn/uqYqX9/LeQLRzgHB0kEt STKVZnpuPhhafE1Tlb/a67kC0c4CQR3ElmNuaTkYvLrAX/j5qHtG9sM+R0VRbLnoRdt2ePvGfDAJ zwAf1VTlB/s9rwycAFpOsHQux9vX54Owz2ngAxtt/XtFBo4DDbUg6n5wHIfrSwkWE8lgSPEocM9W trG9IAOTsK6EQtOymskyO78QOHjTwOc0VfnuPk97EzJeAdymbmm5QoFrC0vhmpUGcK9f8+3AkfEW ZgnXnWga8sUiN5YSwfwR4E3gLzVV+WE1P1cGhgHkJopoTOdyLCRWgl4RvCWE7wMe0FSl6iUEZbz1 4ZAa3FVnOw7JVJrF5Cq5teXnFoF/AB7UVCVVq+8i460r0pAJE47jkMrmSKbSrKQz4UTVn+NVRP2+ pio1X7NJBnoBRKExRLNsm5V0hpW0t4B9SKgs8H3gIb9QSt2QgQiAKNbHWlu0LDLZHJl8gUwuF8S3 BljAU8DDeOFOyXqKFVCzLtNxXQrFIvlCiXyxSL5YJJsvbFZrbRkvVPMx4HFNVRquGrEM9AMsJJJ0 yDKyJCFJIpIoIYliOU9AENZVQSknjTqui+042I6NbTvYjoNl2RQtC8uyKFoWpZK13erbc8BP8dbi ewq4tJM3qN7IwCvArb4VoJoU8MZRrwIvAS8Dz+/GzNwoyMAfAiowDhwF4sCg/xoAoqF9g20HCDzQ RbyQpGTo5wIwA8z6P68Cc5U6Lhqd/weysBB95onSUgAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOS0w Ny0xOVQxNzoyMjozMCswODowMDMv8gcAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTktMDctMTlUMTc6 MjI6MzArMDg6MDBCckq7AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAABJ RU5ErkJggg=="
      });
    }

    function _build_nodes(node){
      /*
        this builds up the real/fake nodes and links needed
        - a node on the "spine" can be like:
          - o--->

              |
          - o-+->

              |
          - o-+->
              |

        - a node off a "rib" or "subrib" can be like:

          - o--->

              \
          - o--->

      */
      _nodes.push(node);

      var cx = 0;
//      console.log('node'+node)
//      console.log(node.connector);
      var between = [node,node.connector],
        nodeLinks = [{
          source: node,
          target: node.connector,
          arrow: true,
          depth: node.depth || 0
        }],
        prev,
        childLinkCount;

      if(!node.parent){
        _nodes.push(prev = {tail: true});
        between = [prev, node];
        nodeLinks[0].source = prev;
        nodeLinks[0].target = node;
        node.horizontal = true;
        node.vertical = false;
        node.depth = 0;
        node.root = true;
        node.totalLinks = []
      }else{
        node.connector.maxChildIdx = 0;
        node.connector.totalLinks = [];
      }

      node.linkCount = 1;

      (_children(node) || []).forEach(function(child, idx){
        child.parent = node;
        child.depth = (node.depth || 0) + 1;
        child.childIdx = idx;
        child.region = node.region ? node.region : (idx & 1 ? 1 : -1);
        child.horizontal = !node.horizontal;
        child.vertical = !node.vertical;

        if(node.root && prev && !prev.tail){
          _nodes.push(child.connector = {
            between: between,
            childIdx: prev.childIdx
          })
          prev = null;
        }else{
          _nodes.push(prev = child.connector = {between: between, childIdx: cx++});
        }

        nodeLinks.push({
          source: child,
          target: child.connector,
          depth: child.depth
        });

        // recurse capturing number of links created
        childLinkCount = _build_nodes(child);
        node.linkCount += childLinkCount;
        between[1].totalLinks.push(childLinkCount);
      });

      between[1].maxChildIdx = cx;

      Array.prototype.unshift.apply(_links, nodeLinks);

      // the number of links created byt this node and its children...
      // TODO: use `linkCount` and/instead of `childIdx` for spacing
      return node.linkCount;
    }


    function _linePosition($){
      $.attr({
        x1: function(d){
          source_x=null;
          if(typeof d!='undefined' && 'depth' in d && d.depth===0){
            source_x=80;
          }else{
            source_x=d.source.x;
          }
          return source_x;
        },
        y1: function(d){ return d.source.y; },
        x2: function(d){
          target_x=null;
          if(typeof d!='undefined' && 'depth' in d &&d.depth===0){
            target_x=d.target.x-50;
          }else{
            target_x=d.target.x;
          }
          return target_x;
        },
        y2: function(d){ return d.target.y; }
      })
    }


    function _nodePosition($){
      // uses an SVG `transform` to position nodes


      $.attr("transform", function(d){


        return "translate(" + d.x + "," + d.y + ")";
      })
    }


    function _linkDistance(d){
      // make longer links for nodes with more children, or of lower depth
      return (d.target.maxChildIdx + 1) * _linkScale(d.depth + 1);
    }

    //defined
    function _defined(e){

      /*
        the primary layout mechanism: a fair amount of the work is done
        by links, but override a lot of it here.

        TODO: enable tweaks to these individual rules
      */
      // this is a "little bit"
      var k = 6 * e.alpha,
        // cache some variables
        size = _force.size(),
        width = size[0],
        height = size[1],
        // scratch variables for lengthy expressions
        a,
        b;
      _nodes.forEach(function(d){
        // handle the middle... could probably store the root width...
        if(d.root){
          d.x = width - (_margin + _root.getBBox().width);
          d.y = height / 2;
        }
        if(d.tail){ d.x = _margin; d.y = height / 2; }

        // put the first-generation items at the top and bottom
        if(d.depth === 1){
          d.y = d.region === -1 ? _margin : (height - _margin);
        }

        if (d.depth && d.id != null) {
          try {
            var gWidth = $('g.' + d.id)[0].getBBox().width;
            var gHeight = $('g.' + d.id)[0].getBBox().height;
            if (gWidth + d.x > $('svg').width()) {
              d.x = $('svg').width() - gWidth;
            } else if (d.x - gWidth < 0) {
              d.x = gWidth;
            }
            if (gHeight + d.y > $('svg').height()) {
              d.y = $('svg').height() - gHeight;
            } else if (d.y - gHeight < 0) {
              d.y = gHeight;
            }
          } catch(err) {}
        }

      if (d.depth > 1 && d.depth % 2 == 0 && d.connector != null) {
        var x1 = d.connector.x;
        var x2 = d.x;
        if (x2 != null && d.id != null) {
          var $text =  $($($('g.' + d.id)[0]).find('text')[0]);
          if (x1 - x2 > 0 && $text.attr('text-anchor') != 'end') {
            $text.attr('text-anchor', 'end');
          } else if (x1 - x2 < 0 && $text.attr('text-anchor') != 'start') {
            $text.attr('text-anchor', 'start');
          }
        }
      }
      if (d.depth > 2 && d.depth % 2 == 1 && d.connector != null) {
        var y1 = d.connector.y;
        var y2 = d.y;
        if (y2 != null && d.id != null) {
          var $text =  $($($('g.' + d.id)[0]).find('text')[0]);
          if (y1 - y2 > 0 && $text.attr('dy') != '-.2em') {
            $text.attr('dy', '-.2em');
          } else if (y1 - y2 < 0 && $text.attr('dy') != '1em') {
            $text.attr('dy', '1em');
          }
        }
      }

        // position synthetic nodes at evently-spaced intervals...
        // TODO: do something based on the calculated size of each branch
        // since we don't have individual links anymore
        if(d.between){
          a = d.between[0];
          b = d.between[1];

          d.x = b.x - (1 + d.childIdx) * (b.x - a.x) / (b.maxChildIdx + 1);
          d.y = b.y - (1 + d.childIdx) * (b.y - a.y) / (b.maxChildIdx + 1);
        }
        _perNodeTick(d);
      });

      // actually apply all changes

      _node.call(_nodePosition);
      _link.call(_linePosition);
    }
    d3.fishbone.tick = function(e) {
      _tick(e);
    }

    //defined
    function _tick(e){
      /*
        the primary layout mechanism: a fair amount of the work is done
        by links, but override a lot of it here.

        TODO: enable tweaks to these individual rules
      */

      // this is a "little bit"
      var k = 6 * e.alpha,
        // cache some variables
        size = _force.size(),
        width = size[0],
        height = size[1],
        // scratch variables for lengthy expressions
        a,
        b;

      _nodes.forEach(function(d){
        // handle the middle... could probably store the root width...
        if(d.root){ d.x = width - (_margin + _root.getBBox().width); }
        if(d.tail){ d.x = _margin; d.y = height / 2; }

        // put the first-generation items at the top and bottom
        if(d.depth === 1){
          d.y = d.region === -1 ? _margin : (height - _margin);
          d.x -= 10 * k;
        }

        // vertically-oriented tend towards the top and bottom of the page
        if(d.vertical){ d.y += k * d.region; }

        // everything tends to the left
        if(d.depth){ d.x -= k;}

        // position synthetic nodes at evently-spaced intervals...
        // TODO: do something based on the calculated size of each branch
        // since we don't have individual links anymore
        if(d.between){
          a = d.between[0];
          b = d.between[1];

          d.x = b.x - (1 + d.childIdx) * (b.x - a.x) / (b.maxChildIdx + 1);
          d.y = b.y - (1 + d.childIdx) * (b.y - a.y) / (b.maxChildIdx + 1);
        }

        _perNodeTick(d);
      });

      // actually apply all changes
      _node.call(_nodePosition);
      _link.call(_linePosition);
    }

    // the d3.fishbone() public API
    // read-only
    fb1.links = function(){ return _links; };
    fb1.nodes = function(){ return _nodes; };
    fb1.force = function(){ return _force; };

    // callable
    fb1.defaultArrow = _arrow;

    // d3-style chainable
    fb1.margin = function(_){
      // how big is the whitespace around the diagram?
      if(!arguments.length){ return _margin; }
      _margin = _;
      return my;
    };

    fb1.children = function(_){
      // how  will children be sought from each node?
      if(!arguments.length){ return _children; }
      _children = _;
      return my;
    };

    fb1.label = function(_){
      // how will a label be sought from each node?
      if(!arguments.length){ return _label; }
      _label = _;
      return my;
    };

    fb1.perNodeTick = function(_){
      // what custom rules should be done per node?
      if(!arguments.length){ return _perNodeTick; }
      _perNodeTick = _;
      return my;
    };

    return fb1;
  }; // d3.fishbone
}).call(this, d3);