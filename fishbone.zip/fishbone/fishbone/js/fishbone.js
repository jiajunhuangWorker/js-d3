/**
 * Created by lhn on 2017/3/28.
 */
var mainFishBone="#52abf0";
var mainFishBoneTxt="#252525";
var fishBoneTwo="#52abf0";
var fishBoneTwoTxt="#252525";
var fishBoneThree="#52abf0";
var fishBoneThreeTxt="#252525";
var fishBoneFour="#52abf0";
var fishBoneFourTxt="#252525";
var fishbone = {
    params: {
        width: 1600,//画布宽度，默认宽度，随着内容的增加而增加
        //height: 800,//画布高度,原始高度
        height: 692,//画布高度
        left: 15,//鱼左边边距
        right: 16,//鱼右边边距
        bonelinW: 4,//鱼骨核心线条高度
        fistbone: {
            right: 50,//一级的离鱼头50
            //topFlineX: 1286,//上面线条的顶部x坐标，画布800
            //topFlineY: 107,//上面线条的顶部y坐标，画布800
            topFlineX: 1286,//上面线条的顶部x坐标,默认值
            topFlineY: 53,//上面线条的顶部y坐标
            spaceX: 460,//两个鱼骨间隔距离
            //bottomFlineX: 1115,//下面线条的顶部x坐标，画布800
            //bottomFlineY: 694,//下面线条的顶部坐标，画布800
            bottomFlineX: 1116,//下面线条的顶部x坐标
            bottomFlineY: 642,//下面线条的顶部坐标
            //botToTopspace: 1 / 3,//下面起点坐标位置距离上面起点为间隙(spaceX)的1/3 废弃，误差偏大
            bottomMoveX: 1283//下面起点坐标位置x
        },
        secondbone: {//二级鱼骨配置
            //topMoveX: 1394,//上面起点x,第一版本的坐标，减少中间空隙
            //topMoveY: 290,//上面起点y,第一版本的坐标，减少中间空隙
            //topMoveX: 1409,//上面起点x，画布800
            //topMoveY: 319,//上面起点y，画布800
            topMoveX: 1409,//上面起点x
            topMoveY: 265,//上面起点y
            lineLen: 156,//线条长
            spaceY: 95,//同册两根y的间距
            spaceX: 55,//同册两根x的间距
            //bottomMoveX: 1220,//下面起点x,第一版本的坐标，减少中间空隙
            //bottomMoveY: 512,//下面起点y,第一版本的坐标，减少中间空隙
            //bottomMoveX: 1241,//下面起点x，画布800
            //bottomMoveY: 476,//下面起点y，画布800
            bottomMoveX: 1241,//下面起点x
            bottomMoveY: 422,//下面起点y
        },
        thirdbone: {//三级鱼骨配置
            top: {//主鱼骨上侧
                left: {//一级级鱼骨左侧
                    topMoveOffsetX: -65,//两个的时候：二级鱼骨上面的三级鱼骨距离一级鱼骨的偏移量（靠近一级鱼骨的那个）
                    bottomMoveOffsetX: -38,//两个的时候：二级鱼下面的三级鱼骨距离一级鱼骨的偏移量（靠近一级鱼骨的那个）
                    bottomOneMoveOffsetX: -89,//一个的时候,二级鱼骨下面起点位置距离一级鱼骨偏移量
                    topOneMoveOffsetX: -80,//一个的时候,二级鱼骨上面起点位置距离一级鱼骨偏移量
                    bottomFontAlign: "right",////两个的时候，二级鱼下面的三级鱼骨距离一级鱼骨最远的那个字体水平对齐方式，
                    topFontAlign: "right",////两个的时候，二级鱼上面的三级鱼骨距离一级鱼骨最远的那个字体水平对齐方式，
                },
                right: {//一级鱼骨右侧
                    topMoveOffsetX: 75,//两个的时候：二级鱼骨上面的三级鱼骨距离一级鱼骨的偏移量（靠近一级鱼骨的那个）
                    bottomMoveOffsetX: 50,//两个的时候：二级鱼下面的三级鱼骨距离一级鱼骨的偏移量（靠近一级鱼骨的那个）
                    bottomOneMoveOffsetX: 89,//一个的时候,二级鱼骨下面起点位置距离一级鱼骨偏移量
                    topOneMoveOffsetX: 80,//一个的时候,二级鱼骨上面起点位置距离一级鱼骨偏移量
                    bottomFontOffsetX: -24,//两个的时候，二级鱼下面的三级鱼骨距离一级鱼骨的那个字体偏移量，超过4个字小于6的时候使用
                    bottomFontOffset2X: -8,//两个的时候，二级鱼下面的三级鱼骨距离一级鱼骨的那个字体偏移量，超过6个字的时候使用
                    bottomFontAlign: "left",//两个的时候，二级鱼下面的三级鱼骨距离一级鱼骨的那个字体水平对齐方式，超过4个字的时候使用
                    topFontAlign: "right",////两个的时候，二级鱼上面的三级鱼骨距离一级鱼骨的那个字体水平对齐方式，在同一行的时候
                    bottomFontDir: -1//字体偏移方向
                },

            },

            bottom: {//主鱼骨下侧
                left: {//一级级鱼骨左侧
                    topMoveOffsetX: -38,//两个的时候：二级鱼骨上面的三级鱼骨距离一级鱼骨的偏移量（靠近一级鱼骨的那个）
                    bottomMoveOffsetX: -65,//两个的时候：二级鱼下面的三级鱼骨距离一级鱼骨的偏移量（靠近一级鱼骨的那个）
                    bottomOneMoveOffsetX: -80,//一个的时候,二级鱼骨下面起点位置距离一级鱼骨偏移量
                    topOneMoveOffsetX: -89,//一个的时候,二级鱼骨上面起点位置距离一级鱼骨偏移量
                    bottomFontAlign: "right",////两个的时候，二级鱼下面的三级鱼骨距离一级鱼骨最远的那个字体水平对齐方式，
                    topFontAlign: "right",////两个的时候，二级鱼上面的三级鱼骨距离一级鱼骨最远的那个字体水平对齐方式，
                },
                right: {//一级鱼骨右侧
                    topMoveOffsetX: 50,//两个的时候：二级鱼骨上面的三级鱼骨距离一级鱼骨的偏移量（靠近一级鱼骨的那个）
                    bottomMoveOffsetX: 75,//两个的时候：二级鱼下面的三级鱼骨距离一级鱼骨的偏移量（靠近一级鱼骨的那个）
                    bottomOneMoveOffsetX: 80,//一个的时候,二级鱼骨下面起点位置距离一级鱼骨偏移量
                    topOneMoveOffsetX: 89,//一个的时候,二级鱼骨上面起点位置距离一级鱼骨偏移量
                    topFontOffsetX: -24,//两个的时候，二级鱼下面的三级鱼骨距离一级鱼骨的那个字体偏移量，超过4个字小于6的时候使用
                    topFontOffset2X: -8,//两个的时候，二级鱼下面的三级鱼骨距离一级鱼骨的那个字体偏移量，超过6个字的时候使用
                    bottomFontAlign: "right",//两个的时候，二级鱼下面的三级鱼骨距离一级鱼骨的那个字体水平对齐方式，超过4个字的时候使用
                    topFontAlign: "left",////两个的时候，二级鱼上面的三级鱼骨距离一级鱼骨的那个字体水平对齐方式，在同一行的时候
                    topFontDir: -1//字体偏移方向
                },
            },
            lineOffsetX: 10,//斜线x偏移量
            lineOffsetY: 14,//斜线y偏移量
            twoSpace: 70,//两个鱼骨之间间距
            lineOffsetHX: 17,//字体错开
            lineOffsetHY: 28,//字体错开
            //towFontLX:12,//两个的时候，字数超过3个的时候，偏移量，texAlign且采用"left"对齐
        },
        imgs: {
            head: {
                url: "img/fishBone_head.png",
                w: 78,
                h: 113
            },
            tail: {
                url: "img/fishBone_tail.png",
                w: 30,
                h: 113
            },
        }
    },
    init: function (data, boneFlag) {

        this.initData = data;
        if (!this.initCanvas) {
            this.rawParams = $.extend(true,{}, this.params);//备份原始数据
         }else{
            this.params = $.extend(true,{}, this.rawParams);//备份原始数据
        }
        //设置鱼骨头的宽度
        this.fishNO=1;
        if(data.bones&&data.bones.length){
            this.fishNO=Math.ceil((data.bones.length||1)/2);
        }
        var p=this.params.fistbone,subLen=(3-this.fishNO)* p.spaceX;
        var width=this.fishNO>=3?1600:1600-subLen;
        this.canvasEl = document.getElementById("fishbone" + boneFlag);
        this.canvasEl.width=width;
        this.params.width=width;
        this.params.fistbone.topFlineX=p.topFlineX-subLen;
        this.params.fistbone.bottomFlineX=p.bottomFlineX-subLen;
        this.params.fistbone.bottomMoveX= p.bottomMoveX-subLen;
        var secondP=this.params.secondbone;
        this.params.secondbone.topMoveX=secondP.topMoveX-subLen;
        this.params.secondbone.bottomMoveX=secondP.bottomMoveX-subLen;

        this.fisC = this.canvasEl.getContext("2d");
        this.fisC.translate(-60, 0);
        this.drawFish();
        this.fistFishbone();
        this.initCanvas = true;
    },
    drawFish: function () {
        var _sel = this;
        var hP = this.params.imgs.head;
        var tP = this.params.imgs.tail;
        //15px 是离右边位置
        var hx = _sel.params.width - _sel.params.left - hP.w;
        var hy = (_sel.params.height - hP.h) / 2;
        this.headX = hx;//画鱼头x坐标

        //画鱼头
        this.createImg(hP.url, function (img) {
            _sel.fisC.drawImage(img, hx-40, hy-18);
            //鱼头文字
            var title = _sel.initData.title;
            var titW = _sel.fisC.measureText(title).width + (title.length - 1) * 2;//获取字体宽度,加上间距宽度2
            _sel.text(title, hx + 14, hy + (hP.h - titW) / 2 + 10,mainFishBoneTxt, "14px 微软雅黑", "alphabetic", "start", 14 + 2);//离鱼头14px间距 +10偏差
        });
        //画主干
        var lineWidth = this.params.bonelinW+3, by = hy + (hP.h - lineWidth) / 2, lineToX = _sel.params.right + tP.w - 15;//-15 是为了让鱼骨与鱼尾连接起来
        this.boneY = by;//主干y坐标
        this.line(lineToX +90, by, hx, by, "source-over", lineWidth, mainFishBone);
        //画尾巴
        var tx = this.params.left + 60;
        this.createImg(tP.url, function (img) {
            _sel.fisC.drawImage(img, tx, hy-28);
        });
    },
    /**
     * 画一级鱼骨
     */
    fistFishbone: function () {
        var bones = this.initData.bones, _sel = this;
        if (bones && bones.length > 0) {
            var c = this.params.fistbone;
            var moveX = this.headX - c.right;//上面起点位置
            var topLineX = c.topFlineX;//上面线终点位置
            var bottomMoveY = this.boneY + this.params.bonelinW - 2;//下面起点y坐标位置,缝隙太大，+2减少缝隙
            //var bottomMoveX = moveX - c.spaceX * c.botToTopspace;//下面起点x坐标 误差太大废弃计算，直接写死
            var bottomMoveX = c.bottomMoveX;
            var bottomLineX = c.bottomFlineX;//下面线终点位置
            $.each(bones, function (i) {
                if (i >= 6) {
                    //console.log("一级鱼骨超出6个");
                    return false;
                }
                if (i % 2 == 0) {//上
                    _sel.line(topLineX, c.topFlineY, moveX, _sel.boneY,"","4",fishBoneTwo);
                    _sel.text(this.title, topLineX, c.topFlineY,fishBoneTwoTxt, "14px 微软雅黑",);
                    topLineX -= c.spaceX;
                    moveX -= c.spaceX;
                } else {//下
                    _sel.line(bottomLineX, c.bottomFlineY, bottomMoveX, bottomMoveY,"","4",fishBoneTwo);
                    _sel.text(this.title, bottomLineX, c.bottomFlineY,fishBoneTwoTxt, "14px 微软雅黑", "top");
                    bottomLineX -= c.spaceX;
                    bottomMoveX -= c.spaceX;

                }
                //画二级鱼骨
                if (this.bones && this.bones.length > 0) {
                    _sel.secondFishbone(this.bones, i);
                }
            })
        }
    },
    /**
     * 画二级鱼骨
     * @param bones
     * @param number
     */
    secondFishbone: function (bones, number) {
        var _sel = this;
        var c = this.params.secondbone;
        var fc = this.params.fistbone;
        if (number % 2 == 0) {//上面
            number = number / 2;
            //第一版本的坐标
            ////上面右侧
            //var topRMoveX = c.topMoveX - number * fc.spaceX;
            //var topRMoveY = c.topMoveY;
            //var topRLineX = topRMoveX + c.lineLen;
            ////上面左侧
            //var topLMoveX = c.topMoveX - 2 - c.spaceX / 2 - number * fc.spaceX;
            //var topLLienY = c.topMoveY - c.spaceY / 2;
            //var topLLineX = topLMoveX - c.lineLen;

            //上面右侧
            var topRMoveX = c.topMoveX - number * fc.spaceX+2 - c.spaceX / 2;
            var topRMoveY = c.topMoveY- c.spaceY / 2;
            var topRLineX = topRMoveX + c.lineLen;
            //上面左侧
            var topLMoveX = c.topMoveX - number * fc.spaceX;
            var topLLienY = c.topMoveY;
            var topLLineX = topLMoveX - c.lineLen;
            //自动设置宽度

            $.each(bones, function (i, bone) {
                if (i >= 4) {
                    //console.log("二级鱼骨超过4个，不显示");
                    return false;
                }
                if (i % 2 == 0) {//右侧
                    _sel.line(topRLineX, topRMoveY, topRMoveX, topRMoveY,'','3',fishBoneThree);
                    _sel.text(bone.title, topRLineX, topRMoveY,fishBoneThreeTxt, "12px 微软雅黑", "middle", "left");
                    //画三级级鱼骨
                    if (bone.bones && bone.bones.length > 0) {
                        _sel.thirdFishbone(bone.bones, topRMoveX, topRMoveY, true, true);
                    }
                    topRMoveX -= c.spaceX;
                    topRMoveY -= c.spaceY;
                    topRLineX -= c.spaceX;

                } else {//左侧
                    _sel.line(topLLineX, topLLienY, topLMoveX, topLLienY,'','3',fishBoneThree);
                    _sel.text(bone.title, topLLineX, topLLienY,fishBoneThreeTxt, "12px 微软雅黑", "middle", "right");
                    //画三级级鱼骨
                    if (bone.bones && bone.bones.length > 0) {
                        _sel.thirdFishbone(bone.bones, topLMoveX, topLLienY, false, true);
                    }
                    topLMoveX -= c.spaceX;
                    topLLienY -= c.spaceY;
                    topLLineX -= c.spaceX;

                }
            });
        } else {//下面
            number = Math.floor(number / 2);
            //第一版本的坐标
            ////右边
            //var bottomRMoveX = c.bottomMoveX - number * fc.spaceX;
            //var bottomRMoveY = c.bottomMoveY;
            //var bottomRLineX = bottomRMoveX + c.lineLen;
            ////左侧
            //var bottomLMoveX = c.bottomMoveX - 2 - c.spaceX / 2 - number * fc.spaceX;
            //var bottomLLienY = c.bottomMoveY + c.spaceY / 2;
            //var bottomLLineX = bottomLMoveX - c.lineLen;
            //右边
            var bottomRMoveX = c.bottomMoveX - number * fc.spaceX;
            var bottomRMoveY = c.bottomMoveY;
            var bottomRLineX = bottomRMoveX + c.lineLen;
            //左侧
            var bottomLMoveX = c.bottomMoveX - 2 - c.spaceX / 2 - number * fc.spaceX;
            var bottomLLienY = c.bottomMoveY + c.spaceY / 2;
            var bottomLLineX = bottomLMoveX - c.lineLen;
            $.each(bones, function (i, bone) {
                if (i >= 4) {
                    //console.log("二级鱼骨超过4个，不显示");
                    return false;
                }
                if (i % 2 == 0) {//右侧
                    _sel.line(bottomRLineX, bottomRMoveY, bottomRMoveX, bottomRMoveY,'','3',fishBoneThree);
                    _sel.text(bone.title, bottomRLineX, bottomRMoveY,fishBoneThreeTxt, "12px 微软雅黑", "middle", "left");
                    //画三级级鱼骨
                    if (bone.bones && bone.bones.length > 0) {
                        _sel.thirdFishbone(bone.bones, bottomRMoveX, bottomRMoveY, true, false);
                    }
                    bottomRMoveX -= c.spaceX;
                    bottomRMoveY += c.spaceY;
                    bottomRLineX -= c.spaceX;
                } else {//左侧
                    _sel.line(bottomLLineX, bottomLLienY, bottomLMoveX, bottomLLienY,'','3',fishBoneThree);
                    _sel.text(bone.title, bottomLLineX, bottomLLienY,fishBoneThreeTxt, "12px 微软雅黑", "middle", "right");
                    //画三级级鱼骨
                    if (bone.bones && bone.bones.length > 0) {
                        _sel.thirdFishbone(bone.bones, bottomLMoveX, bottomLLienY, false, false);
                    }
                    bottomLMoveX -= c.spaceX;
                    bottomLLienY += c.spaceY;
                    bottomLLineX -= c.spaceX;
                }

            });
        }
    },
    thirdFishbone: function (bones, secondMoveX, secondMoveY, isRight, isTop) {
        var _sel = this;
        var c = this.params.thirdbone;
        var len = bones.length;
        var moveX;
        var moveY = secondMoveY;
        var lineX, lineY, textBaseline, moveOffsetX, thirdIsTop, fontX, fontY, fontAlign, lineOffsetX, lineOffsetY;
        var cInfo, twoSpace;
        if (isTop) {
            cInfo = c.top;
        } else {
            cInfo = c.bottom;
        }
        if (isRight) {
            twoSpace = c.twoSpace;
            cInfo = cInfo.right;
        } else {
            cInfo = cInfo.left;
            twoSpace = -c.twoSpace;
        }
        $.each(bones, function (i, bone) {
            var title = bone.title;
            if (i >= 4) {
                //console.log("三级鱼骨数量超过4个将不显示");
                return false;
            }
            lineX = 0, lineY = 0, textBaseline = null, moveOffsetX = 0, fontX = 0, fontY = 0, fontAlign = "center", lineOffsetX = c.lineOffsetX, lineOffsetY = c.lineOffsetY;
            switch (len) {
                case 1:
                    thirdIsTop = isTop ? "bottom" : "top";
                    moveOffsetX = cInfo[thirdIsTop + "OneMoveOffsetX"];
                    break;
                case 2:
                    switch (i) {
                        case 0:
                            thirdIsTop = isTop ? "bottom" : "top";
                            moveOffsetX = cInfo[thirdIsTop + "OneMoveOffsetX"];
                            break;
                        case 1:
                            thirdIsTop = isTop ? "top" : "bottom";
                            moveOffsetX = cInfo[thirdIsTop + "OneMoveOffsetX"];
                            break;
                    }
                    break;
                case 3:
                    switch (i) {
                        case 0:
                            thirdIsTop = isTop ? "bottom" : "top";
                            moveOffsetX = cInfo[thirdIsTop + "MoveOffsetX"];
                            if (isRight) {

                                    fontX = cInfo[thirdIsTop + "FontOffset2X"];
                                    fontAlign = cInfo[thirdIsTop + "FontAlign"];
                                    lineOffsetX = c.lineOffsetHX;
                                    lineOffsetY = c.lineOffsetHY;
                            }

                            break;
                        case 1:
                            thirdIsTop = isTop ? "bottom" : "top";
                            moveOffsetX = cInfo[thirdIsTop + "MoveOffsetX"] + twoSpace;
                            if (isRight) {
                            } else {
                                    lineOffsetX = c.lineOffsetHX;
                                    lineOffsetY = c.lineOffsetHY;

                            }

                            break;
                        case 2:
                            thirdIsTop = isTop ? "top" : "bottom";
                            moveOffsetX = cInfo[thirdIsTop + "OneMoveOffsetX"];
                            break;
                    }
                    break;
                case 4:
                    switch (i) {
                        case 0:
                            thirdIsTop = isTop ? "bottom" : "top";
                            moveOffsetX = cInfo[thirdIsTop + "MoveOffsetX"];
                            if (isRight) {
                                //所有的要求都上下错开，去掉算法
                                // if (title.length >= 6) {
                                fontX = cInfo[thirdIsTop + "FontOffset2X"];
                                fontAlign = cInfo[thirdIsTop + "FontAlign"];
                                lineOffsetX = c.lineOffsetHX;
                                lineOffsetY = c.lineOffsetHY;
                            }

                            break;
                        case 1:
                            thirdIsTop = isTop ? "bottom" : "top";
                            moveOffsetX = cInfo[thirdIsTop + "MoveOffsetX"] + twoSpace;
                            if (isRight) {
                            } else {
                                lineOffsetX = c.lineOffsetHX;
                                lineOffsetY = c.lineOffsetHY;

                            }

                            break;
                        case 2:
                            thirdIsTop = isTop ? "top" : "bottom";
                            moveOffsetX = cInfo[thirdIsTop + "MoveOffsetX"];
                            if (isRight) {
                                    lineOffsetX = c.lineOffsetHX;
                                    lineOffsetY = c.lineOffsetHY;
                            }
                            break;
                        case 3:
                            thirdIsTop = isTop ? "top" : "bottom";
                            moveOffsetX = cInfo[thirdIsTop + "MoveOffsetX"] + twoSpace;

                            if (!isRight) {
                                    lineOffsetX = c.lineOffsetHX;
                                    lineOffsetY = c.lineOffsetHY;
                            }
                            break;
                    }
                    break;

            }

            moveX = secondMoveX + moveOffsetX;
            lineX = moveX - lineOffsetX;
            if (thirdIsTop == "top") {
                lineY = moveY - lineOffsetY;
                textBaseline = "bottom";
            } else {
                lineY = moveY + lineOffsetY;
                textBaseline = "top";
            }
            _sel.line(lineX, lineY, moveX, moveY, null, null, fishBoneFour);
            _sel.text(title, lineX + fontX, lineY,fishBoneFourTxt, null, textBaseline, fontAlign);
        });
    },
    line: function (lineToX, lineToY, moveX, moveY, globalCompositeOperation, lineWidth, strokeStyle) {
        this.fisC.lineWidth = lineWidth || 2;
        this.fisC.strokeStyle = strokeStyle || mainFishBone;
        this.fisC.globalCompositeOperation = globalCompositeOperation || "destination-over";
        this.fisC.beginPath();
        this.fisC.moveTo(moveX, moveY);
        this.fisC.lineTo(lineToX, lineToY);
        this.fisC.stroke();
        this.fisC.globalCompositeOperation = "source-over";
    },
    /**
     *
     * @param text 文本
     * @param x
     * @param y
     * @param color
     * @param textW  字体宽度，false：不是竖着排列
     * @param font  字体
     */
    text: function (text, x, y, color, font, textBaseline, textAlign, textW) {
        var _sel = this;
        this.fisC.font = font || "12px 微软雅黑";
        this.fisC.fillStyle = color || "#006fb5";
        this.fisC.textBaseline = textBaseline || "bottom";
        this.fisC.textAlign = textAlign || "center";
        if (textW) {
            var textArr = text.split("");
            $.each(textArr, function (i) {
                _sel.fisC.fillText(this, x, y + i * textW);
            })
        } else {
            _sel.fisC.fillText(text, x, y);
        }
    },
    createImg: function (url, calBac) {
        var img = new Image();
        img.onload = function () {
            calBac(img);
        }
        img.src = url;
    },
    /**
     * 清除画布
     */
    clear:function(){
        var c=this.params;
        this.fisC.clearRect(0,0, c.width, c.height);
    },
    getImg:function(){
        return this.canvasEl.toDataURL("image/png");
    }
}


